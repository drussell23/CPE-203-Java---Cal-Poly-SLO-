import processing.core.PImage;
import java.util.List;

final class Fire_Blacksmith extends Abstract_Entity {
    public Fire_Blacksmith(String id, Point position, List<PImage> images)
    {
        super(id, position, images);
    }
}
