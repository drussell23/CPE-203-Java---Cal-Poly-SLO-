import processing.core.PImage;
import java.util.List;

final public class Fire_Background extends Background {
    public Fire_Background(String id, List<PImage> images){
        super(id, images);
    }
}
