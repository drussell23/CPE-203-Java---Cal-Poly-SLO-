public interface AnimationEntity extends Executable
{
    void nextImage();
    int getAnimationPeriod();
}