public interface Moveable extends AnimationEntity {
    Point nextPosition( WorldModel world, Point destPos);

}